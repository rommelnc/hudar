SiegelsEx <- data.frame(x = c(-4:3, 12), y = c(rep(0,6), -5,5,1))
