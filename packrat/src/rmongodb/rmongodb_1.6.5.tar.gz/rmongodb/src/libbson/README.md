MongoDB BSON C Library
================================

Version: 0.4.0

URL: https://github.com/mongodb/libbson

Description: libbson is a library providing useful routines related to building, parsing, and iterating BSON documents. 