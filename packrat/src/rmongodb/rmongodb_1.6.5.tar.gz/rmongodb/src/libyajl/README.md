libyajl
================================

Version: 2.0.4

URL: https://github.com/lloyd/yajl

Description: A fast JSON parsing library in C.
