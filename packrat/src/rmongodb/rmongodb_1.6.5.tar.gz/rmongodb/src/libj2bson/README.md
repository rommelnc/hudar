JSON to BSON conversion library
================================

Version: 0.1.0

URL: https://github.com/jjwchoy/libj2bson

Description: libj2bson is a JSON -> BSON conversion library. It uses libyajl to parse the JSON and libbson to encode the bson.

Depends: libbson 0.4.X & libyajl 2.X.X