MongoDB C Driver
================================

Version: 0.90.0

URL: https://github.com/mongodb/mongo-c-driver

Description: Libmongoc is a client library written in C for MongoDB.
12/2013: Completely new designed MongoDB C Driver.

Depends on: libbson