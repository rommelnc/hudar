
## ----installRmongodb, eval=FALSE-----------------------------------------
## install.packages("rmongodb")


## ----installDEV, eval=FALSE----------------------------------------------
## library(devtools)
## install_github("rmongodb", "mongosoup")


## ----loadRmongodb--------------------------------------------------------
library(rmongodb)


## ----connect2Mongo-------------------------------------------------------
help("mongo.create")
mongo <- mongo.create()
mongo
mongo.is.connected(mongo)


## ----importZIPdata, echo=FALSE, warning=FALSE, results='hide'------------
if(mongo.is.connected(mongo) == TRUE){
  # load some data
  library(jsonlite)
  data(zips)
  # rename _id field. The original zips data set holds duplicate _id values which will fale during the import
  colnames(zips)[5] <- "orig_id"
  
  ziplist <- list()
  ziplist <- apply( zips, 1, function(x) c( ziplist, x ) )
  res <- lapply( ziplist, function(x) mongo.bson.from.list(x) )
  
  mongo.insert.batch(mongo, "rmongodb.zips", res )
}


## ----getDBs--------------------------------------------------------------
if(mongo.is.connected(mongo) == TRUE){
  mongo.get.databases(mongo)
}


## ----getColls------------------------------------------------------------
if(mongo.is.connected(mongo) == TRUE){
  db <- "rmongodb"
  mongo.get.database.collections(mongo, db)
}
coll <- "rmongodb.zips"


## ----count, echo=TRUE----------------------------------------------------
if(mongo.is.connected(mongo) == TRUE){
  help("mongo.count")
  mongo.count(mongo, coll)
}


## ----findOneFirst, echo=TRUE---------------------------------------------
if(mongo.is.connected(mongo) == TRUE){
  mongo.find.one(mongo, coll)
}


## ----Distinct, echo=TRUE-------------------------------------------------
if(mongo.is.connected(mongo) == TRUE){
  res <- mongo.distinct(mongo, coll, "city")
  head( res )
}


## ----findOne-------------------------------------------------------------
if(mongo.is.connected(mongo) == TRUE){
  cityone <- mongo.find.one(mongo, coll, '{"city":"COLORADO CITY"}')
  print( cityone )
  mongo.bson.to.list(cityone)
}


## ----createBSON----------------------------------------------------------
buf <- mongo.bson.buffer.create()
mongo.bson.buffer.append(buf, "city", "COLORADO CITY")
query <- mongo.bson.from.buffer(buf)
query


## ----createBSONoneLine---------------------------------------------------
mongo.bson.from.JSON('{"city":"COLORADO CITY"}')


## ----findMore, warning=FALSE---------------------------------------------
if(mongo.is.connected(mongo) == TRUE){
  pop <- mongo.distinct(mongo, coll, "pop")
  hist(pop)
  boxplot(pop)

  nr <- mongo.count(mongo, coll, '{"pop":{"$lte":2}}')
  print( nr )
  pops <- mongo.find.all(mongo, coll, '{"pop":{"$lte":2}}')
  print( dim(pops) )
  head(pops)
}


## ----compleyQuery--------------------------------------------------------
library(jsonlite)
json <- '{"pop":{"$lte":2}, "pop":{"$gte":1}}'
cat(prettify(json))
validate(json)
if(mongo.is.connected(mongo) == TRUE){
  pops <- mongo.find.all(mongo, coll, json)
  print( dim(pops) )
  head(pops)
}


## ----inefficient---------------------------------------------------------
mongo.cursor.to.data.frame


## ----insert--------------------------------------------------------------
# insert data
a <- mongo.bson.from.JSON( '{"ident":"a", "name":"Markus", "age":33}' )
b <- mongo.bson.from.JSON( '{"ident":"b", "name":"MongoSoup", "age":1}' )
c <- mongo.bson.from.JSON( '{"ident":"c", "name":"UseR", "age":18}' )

if(mongo.is.connected(mongo) == TRUE){
  icoll <- paste(db, "test", sep=".")
  mongo.insert.batch(mongo, icoll, list(a,b,c) )

  dbs <- mongo.get.database.collections(mongo, db)
  print(dbs)
  mongo.find.all(mongo, icoll)
}


## ----update--------------------------------------------------------------
if(mongo.is.connected(mongo) == TRUE){
  mongo.update(mongo, icoll, '{"ident":"b"}', '{"$inc":{"age":3}}' )

  res <- mongo.find.all(mongo, icoll)
  print(res)
  
  # Creating an index for the field 'ident'
  mongo.index.create(mongo, icoll, '{"ident":1}')
  # check mongoshell!
}


## ----dropColls-----------------------------------------------------------
if(mongo.is.connected(mongo) == TRUE){
  mongo.drop(mongo, icoll)
  mongo.drop.database(mongo, db)
  res <- mongo.get.database.collections(mongo, db)
  print(res)
  
  # close connection
  mongo.destroy(mongo)
}


