library(rmongodb)
library(RUnit)

# ? tests
# 22.11.2013


#m <- matrix(NA, nrow=2, ncol=4)

#rbind.nosql


